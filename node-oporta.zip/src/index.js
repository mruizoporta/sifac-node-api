/*require('dotenv').config();
import app from './app.js';


async function main() {

    await app.listen(process.env.PORT);
    console.log('Server on port 5000');
};

main();*/

console.log('Server on port 5000');